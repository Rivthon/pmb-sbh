<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TesKesehatanAnamnesa;
use App\Models\TesKesehatanPemeriksaan;
use PDF;

class AdminTesKesehatanAnamnesaController extends Controller
{

    /**
     * Tampilkan daftar seluruh hasil anamnesa.
     */
    /**
     * Tampilkan daftar seluruh hasil anamnesa.
     */
    public function index(Request $request)
    {
        $query = TesKesehatanAnamnesa::with('user')->latest();

        if ($request->filled('search')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%');
            });
        }

        $anamnesaList = $query->paginate(15);

        return view('admin.tes_kesehatan.index', compact('anamnesaList'));
    }


    /**
     * Tampilkan detail anamnesa tertentu.
     */
    public function show($id)
    {
        $anamnesa = TesKesehatanAnamnesa::with('user')->findOrFail($id);

        return view('admin.tes_kesehatan.show', compact('anamnesa'));
    }

    /**
     * Update status pemeriksaan.
     */
    public function storePemeriksaan(Request $request, $id)
    {
        $anamnesa = TesKesehatanAnamnesa::findOrFail($id);
        $validated = $request->validate([
            'nama_pemeriksa' => 'required|string|max:100',
            'tanggal_pemeriksaan' => 'required|date',
            'tinggi_badan' => 'nullable|numeric',
            'berat_badan' => 'nullable|numeric',
            'tekanan_darah' => 'nullable|string|max:50',
            'konjungtiva' => 'nullable|string|max:100',
            'ikhterik' => 'nullable|string|max:100',
            'buta_warna' => 'nullable|string|max:100',
            'respon_pendengaran' => 'nullable|string|max:100',
            'kelengkapan_jari_atas' => 'nullable|string|max:100',
            'tremor' => 'nullable|string|max:100',
            'kidal' => 'nullable|string|max:100',
            'bekas_luka_sayatan' => 'nullable|string|max:100',
            'bunyi_jantung' => 'nullable|string|max:100',
            'bunyi_paru' => 'nullable|string|max:100',
            'catatan' => 'nullable|string',
            'rekomendasi' => 'nullable|string',
        ]);


        // Set nama dan admin pemeriksa secara otomatis
        $validated['nama_pemeriksa'] = auth()->user()->name;
        // $validated['admin_id'] = auth()->user()->id;

        // Jika ada role checking
        // if (!auth()->user()->hasRole(['Super Admin', 'Petugas Medis'])) {
        //     abort(403, 'Anda tidak memiliki izin untuk melakukan pemeriksaan kesehatan.');
        // }

        TesKesehatanPemeriksaan::updateOrCreate(
            ['tes_kesehatan_anamnesa_id' => $id],
            $validated
        );

        return redirect()
            ->route('admin.tes-kesehatan.show', $id)
            ->with('toastSuccess', 'Hasil pemeriksaan berhasil disimpan.');
        // This method can be implemented if needed
    }
    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:belum diperiksa,lulus,tidak lulus,perlu tindak lanjut',
        ]);

        $anamnesa = TesKesehatanAnamnesa::findOrFail($id);

        // Update status dan admin yang memperbarui
        $anamnesa->status = $request->status;
        $anamnesa->admin_id = auth()->id(); // ✅ tambahkan baris ini

        $anamnesa->save();

        return redirect()
            ->route('admin.tes-kesehatan.show', $id)
            ->with('toastSuccess', 'Status pemeriksaan berhasil diperbarui.');
    }


    /**
     * Hapus data anamnesa.
     */
    public function destroy($id)
    {
        $anamnesa = TesKesehatanAnamnesa::findOrFail($id);
        $anamnesa->delete();

        return redirect()
            ->route('admin.tes-kesehatan.index')
            ->with('toastSuccess', 'Data anamnesa berhasil dihapus.');
    }

    public function cetakPdf($id)
    {
        $anamnesa = TesKesehatanAnamnesa::with(['user', 'pemeriksaan'])->findOrFail($id);

        if (!$anamnesa->pemeriksaan) {
            return redirect()->back()->with('error', 'Data pemeriksaan belum tersedia untuk dicetak.');
        }

        $pdf = PDF::loadView('admin.tes_kesehatan.pdf', [
            'anamnesa' => $anamnesa,
            'pemeriksaan' => $anamnesa->pemeriksaan,
        ])->setPaper('A4', 'portrait');

        return $pdf->stream('Hasil Pemeriksaan - ' . $anamnesa->user->name . '.pdf');
    }
}
