<?php

namespace App\Http\Controllers\Master\Data;

use App\Models\WawancaraPmb;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;


class WawancaraReviewController extends Controller
{
    /**
     * =========================
     * LIST WAWANCARA
     * =========================
     */
    public function index(Request $request)
    {
        $query = WawancaraPmb::query()
            ->with([
                'user:id,name,email,jurusan_id',
                'user.jurusan:id,nama_jurusan',
                'pewawancara:id,name',
            ])
            ->whereIn('status', ['submitted', 'reviewed', 'locked']);

        // 🔍 SEARCH
        if ($request->filled('search')) {
            $search = $request->search;

            $query->where(function ($q) use ($search) {

                $q->whereHas('user', function ($uq) use ($search) {
                    $uq->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%");
                })

                    ->orWhereHas('user.jurusan', function ($jq) use ($search) {
                        $jq->where('nama_jurusan', 'like', "%{$search}%");
                    })

                    ->orWhereHas('pewawancara', function ($pq) use ($search) {
                        $pq->where('name', 'like', "%{$search}%");
                    });
            });
        }

        $data = $query->latest()
            ->paginate(10)
            ->withQueryString();

        return view('admin.wawancara.index', compact('data'));
    }

    /**
     * =========================
     * SHOW (READ ONLY)
     * =========================
     */
    public function show(WawancaraPmb $wawancara)
    {
        $wawancara->load([
            'user.jurusan',
            'pewawancara',
        ]);

        return view('admin.wawancara.show', compact('wawancara'));
    }

    /**
     * =========================
     * REVIEW KAPRODI
     * =========================
     */
    public function edit(WawancaraPmb $wawancara)
    {
        if ($wawancara->status === 'locked') {
            abort(403, 'Wawancara sudah dikunci.');
        }

        $wawancara->load(['user.jurusan', 'pewawancara']);

        return view('admin.wawancara.review', compact('wawancara'));
    }


    public function review(Request $request, WawancaraPmb $wawancara)
    {
        // ⛔ Tidak boleh review jika sudah final
        if ($wawancara->status === 'locked') {
            abort(403, 'Wawancara sudah dikunci.');
        }

        // ⛔ Review hanya boleh dari status submitted
        if ($wawancara->status !== 'submitted') {
            abort(403, 'Wawancara tidak dapat direview.');
        }

        $validated = $request->validate([
            'kesimpulan_kaprodi' => 'required|string|min:10',
            'rekomendasi'        => 'required|in:direkomendasikan,direkomendasikan_bersyarat,tidak_direkomendasikan',
        ]);

        $wawancara->update([
            'kesimpulan_kaprodi' => $validated['kesimpulan_kaprodi'],
            'rekomendasi'        => $validated['rekomendasi'],
            'kaprodi_id'         => Auth::id(),
            'tanggal_review'     => now(),
            'status'             => 'reviewed',
        ]);

        return redirect()
            ->route('admin.wawancara.show', $wawancara)
            ->with('success', 'Review wawancara berhasil disimpan.');
    }


    /**
     * =========================
     * LOCK (FINAL)
     * =========================
     */
    public function lock(WawancaraPmb $wawancara)
    {
        // ⛔ Hanya boleh lock setelah review
        if ($wawancara->status !== 'reviewed') {
            abort(403, 'Wawancara harus direview terlebih dahulu.');
        }

        $wawancara->update([
            'status' => 'locked',
        ]);

        return redirect()
            ->route('admin.wawancara.index')
            ->with('success', 'Hasil wawancara berhasil dikunci (final).');
    }
}