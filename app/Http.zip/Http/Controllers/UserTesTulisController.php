<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\TesTulis;
use App\Models\KategoriSoal;
use Illuminate\Http\Request;
use App\Models\HasilTesTulis;
use App\Models\TesTulisHasilKategori;
use App\Models\TesTulisJawaban;
use Illuminate\Support\Facades\Auth;
use App\Services\MasterData\UserService;

class UserTesTulisController extends Controller
{

    /**
     * Menampilkan daftar tes tulis aktif.
     */
    public function index()
    {
        // Cukup ambil data dengan relasi yang sudah kita buat.
        // Tidak ada lagi foreach atau update di sini.
        $tesTulis = TesTulis::where('status_aktif', true)
            ->with('hasilTesUser') // Gunakan relasi baru yang efisien
            ->latest()
            ->get();

        return view('dashboard.pages.tes-tulis.index', compact('tesTulis'));
    }

    public function show($id)
    {
        $userId = Auth::id();
        $tesTulis = TesTulis::with(['soal.pilihanJawaban', 'soal.kategori'])->findOrFail($id);

        if (!$tesTulis->status_aktif) {
            return redirect()->route('dashboard.user.tes-tulis.index')
                ->with('error', 'Tes ini tidak aktif.');
        }

        $hasil = HasilTesTulis::firstOrNew([
            'user_id' => $userId,
            'tes_tulis_id' => $tesTulis->id,
        ]);

        // Jika belum mulai
        if (!$hasil->exists || !$hasil->waktu_mulai) {
            $hasil->fill([
                'waktu_mulai' => now(),
                'status' => 'berlangsung',
            ])->save();
        }

        // Jika sudah selesai, arahkan ke hasil
        if ($hasil->status === 'selesai') {
            return redirect()->route('dashboard.user.tes-tulis.index')
                ->with('info', 'Anda sudah menyelesaikan tes ini.');
        }

        // Hitung waktu tersisa
        $mulai = Carbon::parse($hasil->waktu_mulai);
        $batas = $mulai->copy()->addMinutes($tesTulis->durasi_menit);
        $now = now();

        if ($now->gte($batas)) {
            // Waktu habis, tandai selesai
            $hasil->update([
                'status' => 'selesai',
                'waktu_selesai' => $now,
            ]);

            return redirect()->route('dashboard.user.tes-tulis.index')
                ->with('error', 'Waktu tes telah habis.');
        }

        $sisaWaktu = max(0, (int)$now->diffInSeconds($batas, false));

        // 🔹 Tambahan kategori soal
        $kategoriList = \App\Models\KategoriSoal::all();

        // 🔹 Kelompokkan soal berdasarkan kategori (optional untuk sidebar)
        $soalPerKategori = $tesTulis->soal->groupBy('kategori_id');

        // Acak soal jika diaktifkan
        $soal = $tesTulis->acak_soal
            ? $tesTulis->soal->shuffle()
            : $tesTulis->soal;

        return view('dashboard.pages.tes-tulis.show', compact(
            'tesTulis',
            'hasil',
            'soal',
            'sisaWaktu',
            'kategoriList',
            'soalPerKategori'
        ));
    }

    public function submit(Request $request, $id)
    {
        $tes = TesTulis::with(['soal.kategori', 'soal.pilihanJawaban'])->findOrFail($id);
        $user = auth()->user();

        // Ambil input jawaban baik dari JSON maupun form
        $jawaban = $request->isJson()
            ? $request->json('jawaban', [])
            : $request->input('jawaban', []);

        if (empty($jawaban)) {
            $message = 'Tidak ada jawaban yang dikirim.';
            return $request->ajax()
                ? response()->json(['success' => false, 'message' => $message], 422)
                : back()->with('error', $message);
        }

        // Ambil atau buat hasil utama
        $hasil = HasilTesTulis::firstOrCreate([
            'user_id' => $user->id,
            'tes_tulis_id' => $tes->id,
        ]);

        $rekapKategori = [];

        foreach ($tes->soal as $soal) {
            $soalId = (int) $soal->id;
            $kategoriId = $soal->kategori_id;

            // Ambil pilihan user (baik integer atau string key)
            $pilihanId = isset($jawaban[$soalId])
                ? (int) $jawaban[$soalId]
                : (isset($jawaban[(string)$soalId]) ? (int) $jawaban[(string)$soalId] : null);

            $pilihan = $soal->pilihanJawaban->firstWhere('id', $pilihanId);

            // Deteksi jawaban benar
            $isBenar = 0;
            if ($pilihan) {
                $isBenar = (int) (
                    ($pilihan->benar ?? $pilihan->is_benar ?? $pilihan->correct ?? false)
                );
            }

            // Rekap per kategori
            if (!isset($rekapKategori[$kategoriId])) {
                $rekapKategori[$kategoriId] = [
                    'jumlah_soal' => 0,
                    'jawaban_benar' => 0,
                    'jawaban_salah' => 0,
                ];
            }

            $rekapKategori[$kategoriId]['jumlah_soal']++;
            $rekapKategori[$kategoriId]['jawaban_benar'] += $isBenar;
            $rekapKategori[$kategoriId]['jawaban_salah'] += !$isBenar;

            // Simpan detail per soal
            TesTulisJawaban::updateOrCreate(
                [
                    'hasil_tes_id' => $hasil->id,
                    'soal_id' => $soalId,
                ],
                [
                    'pilihan_jawaban_id' => $pilihanId,
                    'benar' => $isBenar,
                ]
            );
        }

        // Hitung skor total
        $totalBenar = collect($rekapKategori)->sum('jawaban_benar');
        $totalSoal  = collect($rekapKategori)->sum('jumlah_soal');
        $skorAkhir  = $totalSoal > 0 ? round(($totalBenar / $totalSoal) * 100, 2) : 0;

        // Update hasil utama
        $hasil->update([
            'skor' => $skorAkhir,
            'jawaban_benar' => $totalBenar,
            'jawaban_salah' => $totalSoal - $totalBenar,
            'status' => 'selesai',
            'waktu_selesai' => now(),
        ]);

        // Simpan hasil kategori
        foreach ($rekapKategori as $kategoriId => $data) {
            $skorKategori = $data['jumlah_soal'] > 0
                ? round(($data['jawaban_benar'] / $data['jumlah_soal']) * 100, 2)
                : 0;

            TesTulisHasilKategori::updateOrCreate(
                [
                    'hasil_tes_id' => $hasil->id,
                    'kategori_id' => $kategoriId,
                ],
                [
                    'jumlah_soal' => $data['jumlah_soal'],
                    'jawaban_benar' => $data['jawaban_benar'],
                    'jawaban_salah' => $data['jawaban_salah'],
                    'skor' => $skorKategori,
                ]
            );
        }

        $redirectUrl = route('dashboard.tes-tulis.result', $tes->id);

        // === Respons akhir ===
        if ($request->ajax()) {
            return response()->json([
                'success' => true,
                'message' => 'Jawaban berhasil disimpan dan hasil sudah direkap.',
                'redirect' => $redirectUrl,
                'skor' => $skorAkhir,
            ]);
        }

        return redirect($redirectUrl)->with('success', 'Jawaban berhasil disimpan dan hasil sudah direkap.');
    }



    public function result($id)
    {
        $userId = Auth::id();

        // Ambil hasil utama (total skor, benar, salah, dll)
        $hasil = HasilTesTulis::where('user_id', $userId)
            ->where('tes_tulis_id', $id)
            ->firstOrFail();

        // Ambil rekap hasil per kategori
        $hasilKategori = TesTulisHasilKategori::where('hasil_tes_id', $hasil->id)
            ->with('kategori') // jika relasi kategori ada
            ->get();

        return view('dashboard.pages.tes-tulis.result', compact('hasil', 'hasilKategori'));
    }
}
