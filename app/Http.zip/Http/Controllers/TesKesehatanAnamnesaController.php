<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TesKesehatanAnamnesa;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreTesKesehatanAnamnesaRequest;
use App\Http\Requests\UpdateTesKesehatanAnamnesaRequest;

class TesKesehatanAnamnesaController extends Controller
{
    public function create()
    {
        $user = Auth::user();

        // Cek apakah user sudah pernah mengisi anamnesa
        $existing = TesKesehatanAnamnesa::where('user_id', $user->id)->first();
        if ($existing) {
            return redirect()->route('dashboard.tes-kesehatan.anamnesa.show');
        }

        return view('dashboard.pages.tes_kesehatan.create');
    }

    /**
     * Simpan data anamnesa dari form
     */
    public function store(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'riwayat_penyakit_keluarga' => 'nullable|string',
            'riwayat_penyakit_pribadi'  => 'nullable|string',
            'riwayat_operasi'            => 'nullable|string',
            'konsumsi_obat_rutin'        => 'nullable|string',
            'penyakit_menular'           => 'nullable|string',
            'masalah_kulit'              => 'nullable|string',
            'tumor_benjolan'             => 'nullable|string',
            'epilepsi'                   => 'nullable|string',
            'cedera_kepala'              => 'nullable|string',
            'batuk_kronis'               => 'nullable|string',
            'gangguan_pencernaan'        => 'nullable|string',
            'gangguan_keseimbangan'      => 'nullable|string',
            'claustrophobia'             => 'nullable|string',
            'takut_darah'                => 'nullable|string',
            'kacamata'                   => 'nullable|string',
            'gagap'                      => 'nullable|string',
            'alat_bantu_tulang'          => 'nullable|string',
            'lemah_otot'                 => 'nullable|string',
            'pikiran_bunuh_diri'         => 'nullable|string',
            'kelainan_darah'             => 'nullable|string',
            'riwayat_psikolog'           => 'nullable|string',
            'keterangan'                 => 'nullable|string',
        ]);

        // Tambahkan atribut tambahan
        $validated['user_id'] = $user->id;
        $validated['tanggal_pengisian'] = now();
        $validated['status'] = 'belum diperiksa'; // ✅ default status baru

        TesKesehatanAnamnesa::create($validated);

        return redirect()
            ->route('dashboard.tes-kesehatan.anamnesa.show')
            ->with('success', 'Data anamnesa berhasil disimpan!');
    }

    /**
     * Menampilkan hasil atau status pengisian
     */
    public function show()
    {
        $user = Auth::user();

        $anamnesa = TesKesehatanAnamnesa::with('pemeriksaan')
            ->where('user_id', $user->id)
            ->first();

        if (!$anamnesa) {
            return redirect()->route('dashboard.tes-kesehatan.anamnesa.create');
        }

        return view('dashboard.pages.tes_kesehatan.show', compact('anamnesa'));
    }

    public function cetak()
    {
        $anamnesa = TesKesehatanAnamnesa::with(['user.jurusan', 'pemeriksaan'])
            ->where('user_id', Auth::id())
            ->first();

        if (!$anamnesa) {
            return redirect()
                ->route('dashboard.tes-kesehatan.anamnesa.create')
                ->with('toastError', 'Isi form tes kesehatan terlebih dahulu sebelum mencetak.');
        }

        $pdf = Pdf::loadView('dashboard.pages.tes_kesehatan.pdf', [
            'anamnesa' => $anamnesa,
            'pemeriksaan' => $anamnesa->pemeriksaan,
        ])->setPaper('A4', 'portrait');

        return $pdf->stream('form-tes-kesehatan-' . str($anamnesa->user->name)->slug('-') . '.pdf');
    }
}
