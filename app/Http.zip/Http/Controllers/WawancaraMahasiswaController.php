<?php

namespace App\Http\Controllers;

use App\Models\WawancaraPmb;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WawancaraMahasiswaController extends Controller
{

    public function index()
    {
        $user = Auth::user();

        $wawancara = WawancaraPmb::firstOrCreate(
            ['calon_mahasiswa_id' => $user->id],
            ['status' => 'draft']
        );

        return view('dashboard.pages.wawancara.index', compact('wawancara'));
    }




    public function submit(Request $request)
    {
        $wawancara = WawancaraPmb::where('calon_mahasiswa_id', Auth::id())
            ->firstOrFail();

        // Cegah submit ulang
        if ($wawancara->status !== 'draft') {
            abort(403, 'Wawancara sudah dikirim.');
        }

        // VALIDASI + SIMPAN JAWABAN
        $validated = $request->validate([
            'jawaban_1'        => 'required|string|min:10',
            'kelebihan'        => 'required|string|min:5',
            'kekurangan'       => 'required|string|min:5',
            'jawaban_2'        => 'required|string|min:10',
            'jawaban_4'        => 'required|string|min:10',
            'jawaban_5'        => 'required|string|min:10',
            'jawaban_6'        => 'required|string|min:10',
            'sumber_informasi' => 'nullable|string|max:255',
        ]);

        $wawancara->update(array_merge($validated, [
            'status' => 'submitted',
        ]));

        return redirect()
            ->route('dashboard.dashboard.wawancara.show')
            ->with('success', 'Wawancara berhasil dikirim.');
    }
    public function show()
    {
        $wawancara = WawancaraPmb::where('calon_mahasiswa_id', Auth::id())
            ->firstOrFail();

        return view('dashboard.pages.wawancara.show', compact('wawancara'));
    }

    public function cetak()
    {
        $wawancara = WawancaraPmb::with(['user.jurusan', 'pewawancara'])
            ->where('calon_mahasiswa_id', Auth::id())
            ->first();

        if (!$wawancara || $wawancara->status === 'draft') {
            return redirect()
                ->route('dashboard.wawancara.index')
                ->with('error', 'Kirim form wawancara terlebih dahulu sebelum mencetak.');
        }

        $pdf = Pdf::loadView('dashboard.pages.wawancara.pdf', compact('wawancara'))
            ->setPaper('A4', 'portrait');

        return $pdf->stream('form-wawancara-' . str($wawancara->user->name)->slug('-') . '.pdf');
    }
}
