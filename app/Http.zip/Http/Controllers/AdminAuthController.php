<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use App\Models\Admin;
use Illuminate\Http\Request;
use App\Mail\VerificationCodeMail;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use App\Http\Requests\Auth\AdminRequest;
use App\Helpers\Responses\ObjectResponse;
use App\Helpers\Utilities\RandomGenerator;
use App\Http\Requests\Auth\RegisterRequest;
use App\Services\MasterData\UserService;
use Illuminate\Support\Facades\DB;
use App\Services\Audit\ActivityLogger;

class AdminAuthController extends Controller
{
    public function __construct(
        private readonly ActivityLogger $activityLogger
    ) {}

    public function showLoginForm()
    {
        return view('admin.auth_login'); // Buat view login untuk admin
    }

    public function storeLogin(AdminRequest $request)
{
    // Validasi input dari request
    $requestDTO = $request->validated();

    try {
        // Cari admin berdasarkan email
        $admin = Admin::where('email', $requestDTO['email'])->first();

        // Jika admin tidak ditemukan, arahkan kembali ke halaman login
        if (is_null($admin)) {
            return redirect()->route('admin.login')->with('toastError', 'Email atau password tidak sesuai.');
        }

        // Cek status aktif admin
        if (isset($admin->is_active) && !$admin->is_active) {
            return redirect()->route('admin.login')->with('toastError', 'Akun Anda dinonaktifkan. Silakan hubungi Super Admin.');
        }

        // Proses login menggunakan guard 'admin'
        if (Auth::guard('admin')->attempt([
            'email' => $requestDTO['email'],
            'password' => $requestDTO['password'],
        ])) {
            // Regenerasi session untuk keamanan
            request()->session()->regenerate();

            $this->activityLogger->log(
                'auth',
                'admin.login',
                'Admin berhasil login',
                $admin,
                [],
                ['email' => $admin->email]
            );

            // Arahkan ke dashboard admin setelah login sukses
            return redirect()->route('admin.dashboard')->with('toastSuccess', __('auth.success_login'));
        }

        // Jika password salah, arahkan kembali ke halaman login dengan pesan error
        return redirect()->route('admin.login')->with('toastError', 'Email atau password tidak sesuai.')->withInput();
    } catch (\Throwable $th) {
        // Tangani error dan arahkan kembali dengan pesan error
        return redirect()->route('admin.login')->with('toastError', 'Gagal masuk. Terjadi kesalahan pada server.')->withInput();
    }
}

    public function logout()
    {
        $this->activityLogger->log('auth', 'admin.logout', 'Admin logout');
        Auth::guard('admin')->logout();
        request()->session()->invalidate();
        request()->session()->regenerateToken();

        return redirect()->route('admin.login')->with('toastSuccess', 'Anda berhasil logout');
    }
}
