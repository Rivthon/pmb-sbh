<?php

namespace App\Http\Controllers\Admin;

use App\Events\PmbQueueUpdated;
use App\Http\Controllers\Controller;
use App\Models\Gelombang;
use App\Models\Jurusan;
use App\Models\Periode;
use App\Models\PmbOfflineQueue;
use App\Models\PmbQueueCallLog;
use App\Models\PmbQueueStage;
use App\Models\PmbQueueStageStep;
use App\Models\PmbQueueStatusLog;
use App\Models\PmbTestRoom;
use App\Models\PmbTestSession;
use App\Services\Pmb\PmbOfflineQueueWorkflowService;
use App\Models\TesTulis;
use App\Models\User;
use App\Services\Audit\ActivityLogger;
use DomainException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\View\View;

class PmbOfflineQueueController extends Controller
{
    public function __construct(
        private readonly ActivityLogger $activityLogger,
        private readonly PmbOfflineQueueWorkflowService $workflow,
    )
    {
    }

    public function index(Request $request): View
    {
        $sessions = PmbTestSession::query()
            ->with(['periode', 'gelombang'])
            ->withCount([
                'queues',
                'queues as checked_in_count' => fn ($query) => $query->whereNotNull('checked_in_at'),
                'queues as waiting_count' => fn ($query) => $query->whereIn('status', [
                    PmbOfflineQueue::STATUS_CHECKED_IN,
                    PmbOfflineQueue::STATUS_WAITING,
                ]),
                'queues as completed_count' => fn ($query) => $query->where('status', PmbOfflineQueue::STATUS_COMPLETED),
            ])
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->status))
            ->when($request->filled('periode_id'), fn ($query) => $query->where('periode_id', $request->periode_id))
            ->latest('starts_at')
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('admin.pmb_queue.index', [
            'sessions' => $sessions,
            'periodes' => Periode::orderByDesc('created_at')->get(),
            'statusOptions' => PmbTestSession::statusOptions(),
        ]);
    }

    public function create(): View
    {
        return view('admin.pmb_queue.form', $this->formData(new PmbTestSession(), 'create'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateSession($request);
        $validated['created_by_admin_id'] = auth('admin')->id();

        $session = PmbTestSession::create($validated);
        $this->workflow->ensureDefaultStages($session);
        $this->syncStageConfig($request, $session);

        $this->activityLogger->log(
            'pmb_queue',
            'session_created',
            'Sesi antrian tes offline dibuat.',
            $session,
            [],
            $session->toArray()
        );

        return redirect()
            ->route('admin.pmb-queues.show', $session)
            ->with('success', 'Sesi antrian berhasil dibuat.');
    }

    public function edit(PmbTestSession $session): View
    {
        return view('admin.pmb_queue.form', $this->formData($session, 'edit'));
    }

    public function update(Request $request, PmbTestSession $session): RedirectResponse
    {
        $validated = $this->validateSession($request);
        $oldValues = $session->only(array_keys($validated));

        $session->update($validated);
        $this->workflow->ensureDefaultStages($session);
        $this->syncStageConfig($request, $session);

        $this->activityLogger->log(
            'pmb_queue',
            'session_updated',
            'Sesi antrian tes offline diperbarui.',
            $session,
            $oldValues,
            $session->only(array_keys($validated))
        );

        return redirect()
            ->route('admin.pmb-queues.show', $session)
            ->with('success', 'Sesi antrian berhasil diperbarui.');
    }

    public function destroy(PmbTestSession $session): RedirectResponse
    {
        $session->delete();

        $this->activityLogger->log('pmb_queue', 'session_deleted', 'Sesi antrian tes offline dihapus.', $session);

        return redirect()
            ->route('admin.pmb-queues.index')
            ->with('success', 'Sesi antrian berhasil dihapus.');
    }

    public function show(Request $request, PmbTestSession $session): View
    {
        $this->workflow->ensureDefaultStages($session);
        $session->load(['periode', 'gelombang', 'tesTulis', 'rooms.stage', 'stages']);

        return view('admin.pmb_queue.show', $this->sessionViewData($request, $session));
    }

    public function board(PmbTestSession $session): View
    {
        $session->load(['rooms.stage', 'periode', 'gelombang', 'stages']);
        $payload = $this->workflow->boardPayload($session);

        return view('admin.pmb_queue.board', [
            'session' => $session,
            'boardPayload' => $payload,
            'completedCount' => $session->queues()->where('status', PmbOfflineQueue::STATUS_COMPLETED)->count(),
        ]);
    }

    public function stats(Request $request, PmbTestSession $session)
    {
        $data = $this->sessionViewData($request, $session, false);

        return response()->json([
            'stats' => view('admin.pmb_queue.partials.stats', $data)->render(),
            'call_console' => view('admin.pmb_queue.partials.call_console', $data)->render(),
            'lanes_health' => view('admin.pmb_queue.partials.lanes', array_merge($data, ['stageKey' => \App\Models\PmbQueueStage::KEY_TES_KESEHATAN]))->render(),
            'lanes_interview' => view('admin.pmb_queue.partials.lanes', array_merge($data, ['stageKey' => \App\Models\PmbQueueStage::KEY_WAWANCARA_KAPRODI]))->render(),
            'rows' => view('admin.pmb_queue.partials.rows', $data)->render(),
        ]);
    }

    public function storeRoom(Request $request, PmbTestSession $session)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'code' => ['required', 'string', 'max:30'],
            'stage_id' => ['nullable', 'integer', 'exists:pmb_queue_stages,id'],
            'capacity' => ['required', 'integer', 'min:1', 'max:100'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:999'],
            'status' => ['required', 'in:' . implode(',', array_keys(PmbTestRoom::statusOptions()))],
        ]);

        $room = $session->rooms()->create($validated);

        $this->activityLogger->log('pmb_queue', 'room_created', 'Ruangan tes dibuat.', $room, [], $room->toArray());

        $message = 'Ruangan berhasil ditambahkan.';

        if ($request->expectsJson() || $request->ajax()) {
            return $this->queueFragments($request, $session, $message, ['ok' => true]);
        }

        return back()->with('success', $message);
    }

    public function updateRoomStatus(Request $request, PmbTestRoom $room)
    {
        $validated = $request->validate([
            'status' => ['required', 'in:' . implode(',', array_keys(PmbTestRoom::statusOptions()))],
        ]);

        $old = ['status' => $room->status];
        $room->update($validated);

        $this->activityLogger->log('pmb_queue', 'room_status_updated', 'Status ruangan diperbarui.', $room, $old, $validated);

        $message = 'Status ruangan diperbarui.';

        if ($request->expectsJson() || $request->ajax()) {
            return $this->queueFragments($request, $room->session, $message, ['ok' => true]);
        }

        return back()->with('success', $message);
    }

    public function updateRoom(Request $request, PmbTestRoom $room)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'code' => ['required', 'string', 'max:30'],
            'stage_id' => ['nullable', 'integer', 'exists:pmb_queue_stages,id'],
            'capacity' => ['required', 'integer', 'min:1', 'max:100'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:999'],
            'status' => ['required', 'in:' . implode(',', array_keys(PmbTestRoom::statusOptions()))],
        ]);

        $old = $room->toArray();
        $room->update($validated);

        $this->activityLogger->log('pmb_queue', 'room_updated', 'Data ruangan diperbarui.', $room, $old, $validated);

        $message = 'Ruangan berhasil diperbarui.';

        if ($request->expectsJson() || $request->ajax()) {
            return $this->queueFragments($request, $room->session, $message, ['ok' => true]);
        }

        return back()->with('success', $message);
    }

    public function destroyRoom(Request $request, PmbTestRoom $room)
    {
        if ($room->queues()->whereIn('status', [
            PmbOfflineQueue::STATUS_CALLED,
            PmbOfflineQueue::STATUS_IN_ROOM,
        ])->exists()) {
            $errMessage = 'Ruangan masih memiliki peserta yang sedang dipanggil atau berada di ruangan.';
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json(['ok' => false, 'message' => $errMessage], 422);
            }
            return back()->with('error', $errMessage);
        }

        $session = $room->session;
        $room->delete();

        $message = 'Ruangan berhasil dihapus.';

        if ($request->expectsJson() || $request->ajax()) {
            return $this->queueFragments($request, $session, $message, ['ok' => true]);
        }

        return back()->with('success', $message);
    }

    public function assignParticipants(Request $request, PmbTestSession $session): RedirectResponse
    {
        $validated = $request->validate([
            'user_ids' => ['required', 'array', 'min:1'],
            'user_ids.*' => ['integer', 'exists:users,id'],
            'priority' => ['nullable', 'integer', 'min:0', 'max:9'],
            'check_in_after_add' => ['nullable', 'boolean'],
            'redirect_to' => ['nullable', 'string', 'in:participant_picker'],
        ]);

        $adminId = auth('admin')->id();
        $added = 0;
        $skipped = 0;
        $checkedIn = 0;
        $eligibleUserIds = User::query()
            ->whereIn('id', $validated['user_ids'])
            ->where('role', User::USER_ROLE)
            ->isPmbVerified()
            ->pluck('id')
            ->all();

        foreach ($eligibleUserIds as $userId) {
            $queue = PmbOfflineQueue::firstOrCreate(
                [
                    'session_id' => $session->id,
                    'user_id' => $userId,
                ],
                [
                    'status' => PmbOfflineQueue::STATUS_REGISTERED,
                    'priority' => $validated['priority'] ?? 0,
                    'created_by_admin_id' => $adminId,
                ]
            );

            if ($queue->wasRecentlyCreated) {
                $added++;
                $this->writeStatusLog($queue, null, PmbOfflineQueue::STATUS_REGISTERED, 'Peserta ditambahkan ke sesi.');
            }

            if (!empty($validated['check_in_after_add']) && !$queue->checked_in_at) {
                $this->workflow->checkIn($queue, $adminId);
                $checkedIn++;
            }
        }

        $skipped = count($validated['user_ids']) - count($eligibleUserIds);
        $message = "{$added} peserta baru berhasil ditambahkan ke sesi.";
        if ($checkedIn > 0) {
            $message .= " {$checkedIn} peserta langsung check-in.";
        }
        if ($skipped > 0) {
            $message .= " {$skipped} peserta dilewati karena belum verified atau bukan akun peserta.";
        }

        if (($validated['redirect_to'] ?? null) === 'participant_picker') {
            return redirect()
                ->route('admin.pmb-queues.participants.add', ['session_id' => $session->id])
                ->with($added > 0 ? 'success' : 'error', $message);
        }

        return back()->with($added > 0 ? 'success' : 'error', $message);
    }

    public function participantPicker(Request $request)
    {
        $sessions = PmbTestSession::with(['periode', 'gelombang'])
            ->latest('starts_at')
            ->latest()
            ->get();

        $selectedSession = $request->filled('session_id')
            ? PmbTestSession::with(['periode', 'gelombang'])->find($request->integer('session_id'))
            : $sessions->first();

        $usedUserIds = $selectedSession
            ? $selectedSession->queues()->pluck('user_id')
            : collect();

        // Determine effective periode: from session, from filter, or fallback to active periode
        $effectivePeriodeId = $request->filled('periode_id')
            ? $request->integer('periode_id')
            : ($selectedSession?->periode_id ?? Periode::where('status_periode', 'aktif')->value('id'));

        // Determine effective gelombang: from session or from filter
        $effectiveGelombangId = $request->filled('gelombang_id')
            ? $request->integer('gelombang_id')
            : $selectedSession?->gelombang_id;

        $participants = User::query()
            ->where('role', User::USER_ROLE)
            ->isPmbVerified()
            ->when($effectivePeriodeId, fn ($query) => $query->where('periode_id', $effectivePeriodeId))
            ->when($effectiveGelombangId, fn ($query) => $query->where('gelombang_id', $effectiveGelombangId))
            ->when($request->filled('jurusan_id'), fn ($query) => $query->where('jurusan_id', $request->jurusan_id))
            ->when($request->filled('search'), function ($query) use ($request): void {
                $search = $request->search;
                $query->where(function ($q) use ($search): void {
                    $q->where('name', 'like', "%{$search}%")
                        ->orWhere('email', 'like', "%{$search}%")
                        ->orWhere('code', 'like', "%{$search}%")
                        ->orWhere('phone', 'like', "%{$search}%");
                });
            })
            ->whereNotIn('id', $usedUserIds)
            ->with(['jurusan', 'periode', 'gelombang'])
            ->orderBy('name')
            ->paginate(25)
            ->withQueryString();

        if ($request->ajax()) {
            return view('admin.pmb_queue.partials.participants_table', [
                'participants' => $participants,
                'selectedSession' => $selectedSession,
            ]);
        }

        $periodeList = Periode::orderByDesc('created_at')->get();
        $gelombangList = $effectivePeriodeId
            ? Gelombang::where('periode_id', $effectivePeriodeId)->orderBy('nama_gelombang')->get()
            : Gelombang::orderByDesc('created_at')->get();

        return view('admin.pmb_queue.participants_add', [
            'sessions' => $sessions,
            'selectedSession' => $selectedSession,
            'participants' => $participants,
            'jurusanList' => Jurusan::orderBy('nama_jurusan')->get(),
            'periodeList' => $periodeList,
            'gelombangList' => $gelombangList,
            'effectivePeriodeId' => $effectivePeriodeId,
            'effectiveGelombangId' => $effectiveGelombangId,
        ]);
    }

    public function removeParticipant(PmbOfflineQueue $queue): RedirectResponse
    {
        if ($queue->status !== PmbOfflineQueue::STATUS_REGISTERED) {
            return back()->with('error', 'Peserta yang sudah check-in atau diproses tidak dapat dihapus dari sesi.');
        }

        $queue->delete();

        return back()->with('success', 'Peserta berhasil dihapus dari sesi.');
    }

    public function manualCheckIn(Request $request, PmbTestSession $session): RedirectResponse
    {
        $validated = $request->validate([
            'code' => ['required', 'string', 'max:255'],
        ]);

        $queue = $this->findQueueFromCode($session, $validated['code']);

        if (!$queue) {
            return back()->with('error', 'Kode QR/nomor peserta tidak ditemukan pada sesi ini.');
        }

        return $this->checkInAndRedirect($queue);
    }

    public function bulkCheckIn(Request $request, PmbTestSession $session): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'queue_ids' => ['required', 'array', 'min:1'],
            'queue_ids.*' => ['integer'],
        ]);

        $queues = PmbOfflineQueue::with(['session', 'user'])
            ->where('session_id', $session->id)
            ->whereIn('id', $validated['queue_ids'])
            ->get();

        $success = 0;
        $failed = [];

        foreach ($queues as $queue) {
            if ($queue->checked_in_at) {
                $failed[] = ($queue->queue_code ?: $queue->user?->name ?: 'Peserta') . ' sudah check-in.';
                continue;
            }

            if (in_array($queue->status, [PmbOfflineQueue::STATUS_CANCELLED, PmbOfflineQueue::STATUS_NO_SHOW], true)) {
                $failed[] = ($queue->queue_code ?: $queue->user?->name ?: 'Peserta') . ' tidak bisa check-in dari status saat ini.';
                continue;
            }



            try {
                $this->workflow->checkIn($queue, auth('admin')->id());
                $success++;
            } catch (DomainException $e) {
                $failed[] = ($queue->queue_code ?: $queue->user?->name ?: 'Peserta') . ' ' . $e->getMessage();
            }
        }

        $message = "{$success} peserta berhasil check-in.";
        if ($failed) {
            $message .= ' ' . count($failed) . ' peserta dilewati.';
        }

        if (!$request->expectsJson() && !$request->ajax()) {
            return back()
                ->with($success > 0 ? 'success' : 'error', $message)
                ->with('bulk_errors', $failed);
        }

        return $this->queueFragments($request, $session, $message, [
            'ok' => $success > 0,
            'success_count' => $success,
            'failed_count' => count($failed),
            'errors' => $failed,
        ], $success > 0 ? 200 : 422);
    }

    public function checkInLink(PmbOfflineQueue $queue): RedirectResponse
    {
        return $this->checkInAndRedirect($queue);
    }

    public function callNext(Request $request, PmbTestSession $session)
    {
        $validated = $request->validate([
            'room_id' => ['nullable', 'integer', 'exists:pmb_test_rooms,id'],
            'stage_id' => ['nullable', 'integer', 'exists:pmb_queue_stages,id'],
            'queue_id' => ['nullable', 'integer', 'exists:pmb_offline_queues,id'],
        ]);

        $room = isset($validated['room_id'])
            ? PmbTestRoom::where('session_id', $session->id)->find($validated['room_id'])
            : null;
        $stage = isset($validated['stage_id'])
            ? PmbQueueStage::where('session_id', $session->id)->find($validated['stage_id'])
            : null;

        try {
            $step = $this->workflow->callNext($session, $stage, $room, $validated['queue_id'] ?? null, auth('admin')->id());
        } catch (DomainException $e) {
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json(['ok' => false, 'message' => $e->getMessage()], 422);
            }

            return back()->with('error', $e->getMessage());
        }

        if (!$step) {
            if ($request->expectsJson() || $request->ajax()) {
                return response()->json([
                    'ok' => false,
                    'message' => 'Tidak ada peserta menunggu untuk dipanggil.'
                ], 422);
            }
            return back()->with('error', 'Tidak ada peserta menunggu untuk dipanggil.');
        }

        $message = 'Peserta berhasil dipanggil.';

        if ($request->expectsJson() || $request->ajax()) {
            return $this->queueFragments($request, $session, $message, ['ok' => true]);
        }

        return back()->with('success', $message);
    }

    public function updateQueueStatus(Request $request, PmbOfflineQueue $queue): RedirectResponse
    {
        $result = $this->processQueueAction($request, $queue);

        return back()->with($result['ok'] ? 'success' : 'error', $result['message']);
    }

    public function updateQueueStatusJson(Request $request, PmbOfflineQueue $queue): JsonResponse
    {
        $result = $this->processQueueAction($request, $queue);

        return $this->queueFragments($request, $queue->session, $result['message'], [
            'ok' => $result['ok'],
        ], $result['ok'] ? 200 : 422);
    }

    public function bulkStatus(Request $request, PmbTestSession $session): JsonResponse|RedirectResponse
    {
        $validated = $request->validate([
            'action' => ['required', 'in:complete_test_tulis,hold_health_form,release_health_form,complete_health,complete'],
            'queue_ids' => ['required', 'array', 'min:1'],
            'queue_ids.*' => ['integer'],
            'note' => ['nullable', 'string', 'max:500'],
        ]);

        $queues = PmbOfflineQueue::with(['session', 'user', 'stageSteps.stage'])
            ->where('session_id', $session->id)
            ->whereIn('id', $validated['queue_ids'])
            ->get();

        $success = 0;
        $failed = [];

        foreach ($queues as $queue) {
            $step = $this->activeStepForQueue($queue);

            if (!$step || !$this->bulkActionMatchesStage($validated['action'], $step)) {
                $failed[] = ($queue->queue_code ?: $queue->user?->name ?: 'Peserta') . ' tidak cocok dengan aksi bulk.';
                continue;
            }

            try {
                $this->workflow->updateStep($step, $validated['action'], null, auth('admin')->id(), $validated['note'] ?? null);
                $success++;
            } catch (DomainException $e) {
                $failed[] = ($queue->queue_code ?: $queue->user?->name ?: 'Peserta') . ' ' . $e->getMessage();
            }
        }

        $message = "{$success} peserta berhasil diproses.";
        if ($failed) {
            $message .= ' ' . count($failed) . ' peserta dilewati.';
        }

        if (!$request->expectsJson() && !$request->ajax()) {
            return back()
                ->with($success > 0 ? 'success' : 'error', $message)
                ->with('bulk_errors', $failed);
        }

        return $this->queueFragments($request, $session, $message, [
            'ok' => $success > 0,
            'success_count' => $success,
            'failed_count' => count($failed),
            'errors' => $failed,
        ], $success > 0 ? 200 : 422);
    }

    private function processQueueAction(Request $request, PmbOfflineQueue $queue): array
    {
        $validated = $request->validate([
            'action' => ['required', 'in:in_room,complete,complete_test_tulis,complete_health,hold_health_form,release_health_form,skip,recall,no_show,cancel,hold,release,problem,reactivate'],
            'room_id' => ['nullable', 'integer', 'exists:pmb_test_rooms,id'],
            'step_id' => ['nullable', 'integer', 'exists:pmb_queue_stage_steps,id'],
            'note' => ['nullable', 'string', 'max:500'],
        ]);

        if ($validated['action'] === 'cancel') {
            try {
                $this->workflow->cancelQueue($queue, auth('admin')->id(), $validated['note'] ?? null);
            } catch (DomainException $e) {
                return ['ok' => false, 'message' => $e->getMessage()];
            }

            return ['ok' => true, 'message' => 'Peserta berhasil dibatalkan.'];
        }

        if ($validated['action'] === 'no_show') {
            try {
                $this->workflow->markNoShow($queue, auth('admin')->id(), $validated['note'] ?? null);
            } catch (DomainException $e) {
                return ['ok' => false, 'message' => $e->getMessage()];
            }

            return ['ok' => true, 'message' => 'Peserta ditandai tidak hadir.'];
        }

        if ($validated['action'] === 'reactivate') {
            try {
                $this->workflow->reactivateQueue($queue, auth('admin')->id(), $validated['note'] ?? null);
            } catch (DomainException $e) {
                return ['ok' => false, 'message' => $e->getMessage()];
            }

            return ['ok' => true, 'message' => 'Peserta berhasil diaktifkan kembali.'];
        }

        $step = isset($validated['step_id'])
            ? PmbQueueStageStep::with(['stage', 'queue.session'])->where('queue_id', $queue->id)->find($validated['step_id'])
            : $this->activeStepForQueue($queue);

        if (!$step) {
            $this->workflow->ensureSteps($queue->load('session'));
            $step = $this->activeStepForQueue($queue->fresh(['stageSteps.stage']));
        }

        if (!$step) {
            return ['ok' => false, 'message' => 'Tahap aktif peserta belum tersedia. Check-in peserta terlebih dahulu.'];
        }

        $action = $validated['action'] === 'in_room' ? 'start' : $validated['action'];
        try {
            $this->workflow->updateStep($step, $action, $validated['room_id'] ?? null, auth('admin')->id(), $validated['note'] ?? null);
        } catch (DomainException $e) {
            return ['ok' => false, 'message' => $e->getMessage()];
        }

        return ['ok' => true, 'message' => $this->queueActionMessage($validated['action'], $step)];
    }

    private function activeStepForQueue(PmbOfflineQueue $queue): ?PmbQueueStageStep
    {
        $queue->loadMissing(['stageSteps.stage']);

        return $queue->stageSteps->firstWhere('stage_id', $queue->current_stage_id)
            ?: $queue->stageSteps
                ->whereIn('status', [
                    PmbQueueStageStep::STATUS_WAITING,
                    PmbQueueStageStep::STATUS_CALLED,
                    PmbQueueStageStep::STATUS_PROCESSING,
                    PmbQueueStageStep::STATUS_HELD,
                    PmbQueueStageStep::STATUS_PROBLEM,
                ])
                ->sortBy(fn (PmbQueueStageStep $step) => $step->stage->sort_order ?? 999)
                ->first();
    }

    private function bulkActionMatchesStage(string $action, PmbQueueStageStep $step): bool
    {
        if (in_array($step->status, [PmbQueueStageStep::STATUS_COMPLETED, PmbQueueStageStep::STATUS_SKIPPED, PmbQueueStageStep::STATUS_PENDING], true)) {
            return false;
        }

        return match ($action) {
            'complete_test_tulis' => $step->stage?->key === PmbQueueStage::KEY_TES_TULIS,
            'hold_health_form' => in_array($step->stage?->key, [PmbQueueStage::KEY_TES_TULIS, PmbQueueStage::KEY_TES_KESEHATAN], true),
            'release_health_form' => $step->stage?->key === PmbQueueStage::KEY_TES_KESEHATAN && $step->status === PmbQueueStageStep::STATUS_HELD,
            'complete_health' => $step->stage?->key === PmbQueueStage::KEY_TES_KESEHATAN,
            'complete' => $step->stage?->key === PmbQueueStage::KEY_WAWANCARA_KAPRODI,
            default => false,
        };
    }

    private function queueActionMessage(string $action, PmbQueueStageStep $step): string
    {
        return match ($action) {
            'complete_test_tulis' => 'Tes Tulis di-ACC. Peserta masuk tahap Tes Kesehatan.',
            'hold_health_form' => 'Peserta ditahan untuk menunggu berkas kesehatan manual.',
            'release_health_form' => 'Berkas kesehatan manual diterima. Peserta masuk Tes Kesehatan.',
            'complete_health' => 'Tes Kesehatan di-ACC. Peserta masuk loket wawancara sesuai program studi.',
            'complete' => match ($step->stage?->key) {
                PmbQueueStage::KEY_PEMBERKASAN => 'Berkas di-ACC. Peserta masuk Tes Tulis.',
                PmbQueueStage::KEY_TES_TULIS => 'Tes Tulis di-ACC. Peserta masuk Tes Kesehatan.',
                PmbQueueStage::KEY_TES_KESEHATAN => 'Tes Kesehatan di-ACC. Peserta masuk Wawancara Kaprodi.',
                PmbQueueStage::KEY_WAWANCARA_KAPRODI => 'Wawancara selesai. Proses PMB offline peserta selesai.',
                default => 'Tahap di-ACC dan peserta dipindahkan sesuai alur.',
            },
            'in_room' => 'Peserta mulai diproses pada tahap aktif.',
            'hold' => 'Peserta ditahan pada tahap aktif.',
            'release' => 'Peserta dilepas dan kembali menunggu pada tahap aktif.',
            'skip' => 'Peserta dilewati sementara pada tahap aktif.',
            'recall' => 'Peserta dipanggil ulang pada tahap aktif.',
            'problem' => 'Peserta ditandai bermasalah pada tahap aktif.',
            default => 'Status tahap peserta berhasil diperbarui.',
        };
    }

    private function queueFragments(Request $request, PmbTestSession $session, ?string $message = null, array $meta = [], int $status = 200): JsonResponse
    {
        $data = $this->sessionViewData($request, $session, false);

        return response()->json(array_merge([
            'message' => $message,
            'stats' => view('admin.pmb_queue.partials.stats', $data)->render(),
            'call_console' => view('admin.pmb_queue.partials.call_console', $data)->render(),
            'lanes_health' => view('admin.pmb_queue.partials.lanes', array_merge($data, ['stageKey' => \App\Models\PmbQueueStage::KEY_TES_KESEHATAN]))->render(),
            'lanes_interview' => view('admin.pmb_queue.partials.lanes', array_merge($data, ['stageKey' => \App\Models\PmbQueueStage::KEY_WAWANCARA_KAPRODI]))->render(),
            'rows' => view('admin.pmb_queue.partials.rows', $data)->render(),
        ], $meta), $status);
    }

    public function pass(PmbOfflineQueue $queue): View
    {
        $queue->load(['session.periode', 'session.gelombang', 'user.jurusan', 'room']);

        return view('admin.pmb_queue.pass', ['queue' => $queue]);
    }

    public function export(PmbTestSession $session)
    {
        $fileName = 'laporan-antrian-' . $session->code . '.csv';
        $stages = $this->workflow->ensureDefaultStages($session);

        return Response::streamDownload(function () use ($session, $stages): void {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, array_merge(
                ['Nomor Kedatangan', 'Nama', 'Email', 'Program Studi', 'Status Global', 'Tahap Saat Ini', 'Ruangan', 'Check-in', 'Dipanggil', 'Selesai Global'],
                $stages->map(fn (PmbQueueStage $stage) => 'Tahap ' . $stage->name)->all()
            ));

            $this->baseQueueQuery($session)
                ->orderBy('queue_number')
                ->orderBy('created_at')
                ->chunk(200, function ($queues) use ($handle, $stages): void {
                    foreach ($queues as $queue) {
                        $steps = $queue->stageSteps->keyBy('stage_id');
                        fputcsv($handle, array_merge([
                            $queue->queue_code ?? '-',
                            $queue->user->name ?? '-',
                            $queue->user->email ?? '-',
                            $queue->user->jurusan->nama_jurusan ?? '-',
                            $queue->statusLabel(),
                            $queue->currentStage->name ?? '-',
                            $queue->room->name ?? '-',
                            optional($queue->checked_in_at)->format('Y-m-d H:i:s') ?? '-',
                            optional($queue->last_called_at)->format('Y-m-d H:i:s') ?? '-',
                            optional($queue->completed_at)->format('Y-m-d H:i:s') ?? '-',
                        ], $stages->map(function (PmbQueueStage $stage) use ($steps, $queue): string {
                            $step = $steps->get($stage->id);

                            return $step ? $step->statusLabel() . ' (' . ($queue->queue_code ?? '-') . ')' : '-';
                        })->all()));
                    }
                });

            fclose($handle);
        }, $fileName, ['Content-Type' => 'text/csv']);
    }

    private function validateSession(Request $request): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:160'],
            'type' => ['required', 'in:' . implode(',', array_keys(PmbTestSession::typeOptions()))],
            'periode_id' => ['nullable', 'integer', 'exists:periodes,id'],
            'gelombang_id' => ['nullable', 'integer', 'exists:gelombangs,id'],
            'tes_tulis_id' => ['nullable', 'integer', 'exists:tes_tulis,id'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date', 'after_or_equal:starts_at'],
            'checkin_open_at' => ['nullable', 'date'],
            'checkin_close_at' => ['nullable', 'date', 'after_or_equal:checkin_open_at'],
            'status' => ['required', 'in:' . implode(',', array_keys(PmbTestSession::statusOptions()))],
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);
    }

    private function formData(PmbTestSession $session, string $mode): array
    {
        return [
            'session' => $session,
            'mode' => $mode,
            'periodes' => Periode::orderByDesc('created_at')->get(),
            'gelombangs' => Gelombang::orderByDesc('created_at')->get(),
            'tesTulis' => TesTulis::orderBy('nama_tes')->get(),
            'statusOptions' => PmbTestSession::statusOptions(),
            'typeOptions' => PmbTestSession::typeOptions(),
            'stageDefaults' => PmbQueueStage::defaults(),
            'configuredStages' => $session->exists ? $this->workflow->ensureDefaultStages($session)->keyBy('key') : collect(),
        ];
    }

    private function syncStageConfig(Request $request, PmbTestSession $session): void
    {
        if (!$request->has('stage_active')) {
            return;
        }

        $active = $request->input('stage_active', []);
        $required = $request->input('stage_required', []);

        foreach ($this->workflow->ensureDefaultStages($session) as $stage) {
            $stage->update([
                'is_active' => array_key_exists($stage->key, $active),
                'is_required' => array_key_exists($stage->key, $required),
            ]);
        }
    }

    private function sessionViewData(Request $request, PmbTestSession $session, bool $includeAvailableParticipants = true): array
    {
        $this->workflow->ensureDefaultStages($session);

        $queues = $this->baseQueueQuery($session)
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->status))
            ->when($request->filled('room_id'), fn ($query) => $query->where('room_id', $request->room_id))
            ->when($request->filled('stage_id') || $request->filled('stage_status'), function ($query) use ($request): void {
                $query->whereHas('stageSteps', function ($stepQuery) use ($request): void {
                    if ($request->filled('stage_id')) {
                        $stepQuery->where('stage_id', $request->stage_id);
                    }
                    if ($request->filled('stage_status')) {
                        $stepQuery->where('status', $request->stage_status);
                    }
                });
            })
            ->when($request->filled('search'), function ($query) use ($request): void {
                $search = $request->search;
                $query->where(function ($q) use ($search): void {
                    $q->where('queue_code', 'like', "%{$search}%")
                        ->orWhereHas('user', function ($userQuery) use ($search): void {
                            $userQuery->where('name', 'like', "%{$search}%")
                                ->orWhere('email', 'like', "%{$search}%")
                                ->orWhere('code', 'like', "%{$search}%");
                        });
                });
            })
            ->orderByRaw('CASE WHEN queue_number IS NULL THEN 1 ELSE 0 END')
            ->orderBy('queue_number')
            ->orderBy('created_at')
            ->paginate(25)
            ->withQueryString();
        $queues->setPath(route('admin.pmb-queues.show', $session));

        $availableParticipants = collect();
        if ($includeAvailableParticipants) {
            $usedUserIds = $session->queues()->pluck('user_id');
            $effectivePeriodeId = $session->periode_id ?? Periode::where('status_periode', 'aktif')->value('id');
            $availableParticipants = User::query()
                ->where('role', User::USER_ROLE)
                ->isPmbVerified()
                ->when($effectivePeriodeId, fn ($query) => $query->where('periode_id', $effectivePeriodeId))
                ->when($session->gelombang_id, fn ($query) => $query->where('gelombang_id', $session->gelombang_id))
                ->whereNotIn('id', $usedUserIds)
                ->with('jurusan')
                ->orderBy('name')
                ->limit(300)
                ->get();
        }

        $boardPayload = $this->workflow->boardPayload($session);

        return [
            'session' => $session->loadMissing(['rooms.stage', 'rooms.stageSteps.queue.user', 'periode', 'gelombang', 'tesTulis', 'stages']),
            'queues' => $queues,
            'rooms' => $session->rooms,
            'stages' => $session->stages,
            'availableParticipants' => $availableParticipants,
            'statusOptions' => PmbOfflineQueue::statusOptions(),
            'stageStatusOptions' => PmbQueueStageStep::statusOptions(),
            'roomStatusOptions' => PmbTestRoom::statusOptions(),
            'stats' => $this->queueStats($session),
            'boardPayload' => $boardPayload,
            'stageBoard' => collect($boardPayload['stages']),
            'recentLogs' => PmbQueueStatusLog::with(['queue.user', 'admin'])
                ->where('session_id', $session->id)
                ->latest()
                ->limit(8)
                ->get(),
        ];
    }

    private function baseQueueQuery(PmbTestSession $session)
    {
        return PmbOfflineQueue::with(['user.jurusan', 'user.gelombang', 'room', 'currentStage', 'stageSteps.stage', 'stageSteps.room'])
            ->where('session_id', $session->id)
            ->whereHas('user', fn ($query) => $query->isPmbVerified());
    }

    private function queueStats(PmbTestSession $session): array
    {
        $verifiedQueues = PmbOfflineQueue::where('session_id', $session->id)
            ->whereHas('user', fn ($query) => $query->isPmbVerified());

        $counts = (clone $verifiedQueues)
            ->select('status', DB::raw('count(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status');

        return [
            'total' => (clone $verifiedQueues)->count(),
            'registered' => $counts->get(PmbOfflineQueue::STATUS_REGISTERED, 0),
            'checked_in' => (clone $verifiedQueues)->whereNotNull('checked_in_at')->count(),
            'waiting' => $counts->get(PmbOfflineQueue::STATUS_WAITING, 0) + $counts->get(PmbOfflineQueue::STATUS_CHECKED_IN, 0),
            'called' => $counts->get(PmbOfflineQueue::STATUS_CALLED, 0),
            'in_room' => $counts->get(PmbOfflineQueue::STATUS_IN_ROOM, 0),
            'completed' => $counts->get(PmbOfflineQueue::STATUS_COMPLETED, 0),
            'skipped' => $counts->get(PmbOfflineQueue::STATUS_SKIPPED, 0),
            'no_show' => $counts->get(PmbOfflineQueue::STATUS_NO_SHOW, 0),
        ];
    }

    private function findQueueFromCode(PmbTestSession $session, string $code): ?PmbOfflineQueue
    {
        $code = trim($code);
        $uuid = $code;

        if (preg_match('/check-in\/([a-f0-9-]+)/i', $code, $matches)) {
            $uuid = $matches[1];
        }

        return PmbOfflineQueue::where('session_id', $session->id)
            ->where(function ($query) use ($code, $uuid): void {
                $query->where('uuid', $uuid)
                    ->orWhere('queue_code', $code)
                    ->orWhereHas('user', fn ($userQuery) => $userQuery->where('code', $code)->orWhere('email', $code));
            })
            ->first();
    }

    private function checkInAndRedirect(PmbOfflineQueue $queue): RedirectResponse
    {
        $wasCheckedIn = (bool) $queue->checked_in_at;
        try {
            $checkedIn = $this->workflow->checkIn($queue, auth('admin')->id());
        } catch (DomainException $e) {
            return redirect()
                ->route('admin.pmb-queues.show', $queue->session)
                ->with('error', $e->getMessage());
        }
        $message = $wasCheckedIn
            ? 'Peserta sudah check-in sebelumnya.'
            : "Check-in berhasil. Nomor antrian {$checkedIn->queue_code}. Peserta masuk tahap {$checkedIn->currentStage?->name}.";

        return redirect()
            ->route('admin.pmb-queues.show', $queue->session)
            ->with('success', $message);
    }

    private function transition(PmbOfflineQueue $queue, string $toStatus, string $note, array $extra = [], bool $writeCallLog = false): void
    {
        DB::transaction(function () use ($queue, $toStatus, $note, $extra, $writeCallLog): void {
            $locked = PmbOfflineQueue::whereKey($queue->id)->lockForUpdate()->firstOrFail();
            $fromStatus = $locked->status;

            $locked->update(array_merge(['status' => $toStatus], $extra));

            $this->writeStatusLog($locked, $fromStatus, $toStatus, $note);

            if ($writeCallLog) {
                PmbQueueCallLog::create([
                    'session_id' => $locked->session_id,
                    'queue_id' => $locked->id,
                    'room_id' => $locked->room_id,
                    'admin_id' => auth('admin')->id(),
                    'action' => $toStatus === PmbOfflineQueue::STATUS_CALLED ? 'call' : 'status',
                    'from_status' => $fromStatus,
                    'to_status' => $toStatus,
                    'call_number' => max(1, $locked->call_count),
                    'called_at' => now(),
                    'metadata' => ['note' => $note],
                ]);
            }

            $this->activityLogger->log(
                'pmb_queue',
                'participant_status_updated',
                $note,
                $locked,
                ['status' => $fromStatus],
                ['status' => $toStatus]
            );

            event(new PmbQueueUpdated($locked->fresh(['user.jurusan', 'room', 'session']), $toStatus));
        });
    }

    private function writeStatusLog(PmbOfflineQueue $queue, ?string $fromStatus, string $toStatus, ?string $note = null): void
    {
        PmbQueueStatusLog::create([
            'session_id' => $queue->session_id,
            'queue_id' => $queue->id,
            'admin_id' => auth('admin')->id(),
            'from_status' => $fromStatus,
            'to_status' => $toStatus,
            'note' => $note,
        ]);
    }
}
