<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\PmbOfflineQueue;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PmbQueueController extends Controller
{
    public function index(Request $request): View
    {
        $queues = PmbOfflineQueue::with(['session.periode', 'session.gelombang', 'room'])
            ->where('user_id', $request->user()->id)
            ->latest()
            ->paginate(5);

        return view('dashboard.pages.pmb_queue.index', compact('queues'));
    }

    public function show(PmbOfflineQueue $queue): View
    {
        abort_unless($queue->user_id === auth()->id(), 403);

        $queue->load(['session.periode', 'session.gelombang', 'user.jurusan', 'room', 'currentStage', 'stageSteps.stage', 'stageSteps.room']);

        return view('dashboard.pages.pmb_queue.show', compact('queue'));
    }
}
