<?php

namespace App\Http\Requests\Users;

use Illuminate\Foundation\Http\FormRequest;

class CreateUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|numeric',
            'password' => 'required|string|min:8|confirmed',
            'address' => 'required|string'
        ];
    }

    public function attributes()
    {
        return [
            'name' => 'Nama Lengkap',
            'email' => 'Email',
            'phone' => 'Nomor HP',
            'password' => 'Password',
            'address' => 'Alamat'
        ];
    }
}
