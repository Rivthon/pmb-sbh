<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;

class PmbOfflineQueue extends Model
{
    use HasFactory;

    public const STATUS_REGISTERED = 'registered';
    public const STATUS_CHECKED_IN = 'checked_in';
    public const STATUS_WAITING = 'waiting';
    public const STATUS_CALLED = 'called';
    public const STATUS_IN_ROOM = 'in_room';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_SKIPPED = 'skipped';
    public const STATUS_NO_SHOW = 'no_show';
    public const STATUS_CANCELLED = 'cancelled';

    public const ARRIVAL_NOT_CHECKED_IN = 'not_checked_in';
    public const ARRIVAL_CHECKED_IN = 'checked_in';
    public const ARRIVAL_NO_SHOW = 'no_show';
    public const ARRIVAL_CANCELLED = 'cancelled';

    public const OVERALL_NOT_STARTED = 'not_started';
    public const OVERALL_IN_PROCESS = 'in_process';
    public const OVERALL_COMPLETED = 'completed';
    public const OVERALL_NO_SHOW = 'no_show';
    public const OVERALL_CANCELLED = 'cancelled';

    protected $fillable = [
        'uuid',
        'session_id',
        'room_id',
        'user_id',
        'queue_number',
        'queue_code',
        'qr_token_hash',
        'status',
        'arrival_status',
        'overall_status',
        'current_stage_id',
        'priority',
        'checked_in_at',
        'called_at',
        'last_called_at',
        'entered_at',
        'completed_at',
        'no_show_at',
        'cancelled_at',
        'call_count',
        'notes',
        'created_by_admin_id',
        'checked_in_by_admin_id',
    ];

    protected $casts = [
        'queue_number' => 'integer',
        'priority' => 'integer',
        'call_count' => 'integer',
        'checked_in_at' => 'datetime',
        'called_at' => 'datetime',
        'last_called_at' => 'datetime',
        'entered_at' => 'datetime',
        'completed_at' => 'datetime',
        'no_show_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    protected static function booted(): void
    {
        static::creating(function (self $queue): void {
            $queue->uuid ??= (string) Str::uuid();
            $queue->qr_token_hash ??= hash('sha256', $queue->uuid . '|' . config('app.key'));
        });
    }

    public function getRouteKeyName(): string
    {
        return 'uuid';
    }

    public static function statusOptions(): array
    {
        return [
            self::STATUS_REGISTERED => 'Terdaftar',
            self::STATUS_CHECKED_IN => 'Check-in',
            self::STATUS_WAITING => 'Menunggu',
            self::STATUS_CALLED => 'Dipanggil',
            self::STATUS_IN_ROOM => 'Proses',
            self::STATUS_COMPLETED => 'Selesai',
            self::STATUS_SKIPPED => 'Dilewati',
            self::STATUS_NO_SHOW => 'Tidak Hadir',
            self::STATUS_CANCELLED => 'Dibatalkan',
        ];
    }

    public static function statusTones(): array
    {
        return [
            self::STATUS_REGISTERED => 'secondary',
            self::STATUS_CHECKED_IN => 'info',
            self::STATUS_WAITING => 'primary',
            self::STATUS_CALLED => 'warning',
            self::STATUS_IN_ROOM => 'dark',
            self::STATUS_COMPLETED => 'success',
            self::STATUS_SKIPPED => 'secondary',
            self::STATUS_NO_SHOW => 'danger',
            self::STATUS_CANCELLED => 'danger',
        ];
    }

    public function statusLabel(): string
    {
        return self::statusOptions()[$this->status] ?? Str::headline($this->status);
    }

    public function statusTone(): string
    {
        return self::statusTones()[$this->status] ?? 'secondary';
    }

    public function signedCheckInUrl(): string
    {
        return URL::signedRoute('admin.pmb-queues.check-in-link', $this);
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(PmbTestSession::class, 'session_id');
    }

    public function room(): BelongsTo
    {
        return $this->belongsTo(PmbTestRoom::class, 'room_id');
    }

    public function currentStage(): BelongsTo
    {
        return $this->belongsTo(PmbQueueStage::class, 'current_stage_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'created_by_admin_id');
    }

    public function checkInAdmin(): BelongsTo
    {
        return $this->belongsTo(Admin::class, 'checked_in_by_admin_id');
    }

    public function callLogs(): HasMany
    {
        return $this->hasMany(PmbQueueCallLog::class, 'queue_id');
    }

    public function statusLogs(): HasMany
    {
        return $this->hasMany(PmbQueueStatusLog::class, 'queue_id');
    }

    public function stageSteps(): HasMany
    {
        return $this->hasMany(PmbQueueStageStep::class, 'queue_id');
    }

}
