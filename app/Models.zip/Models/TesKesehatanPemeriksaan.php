<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TesKesehatanPemeriksaan extends Model
{
    use HasFactory;

    protected $table = 'tes_kesehatan_pemeriksaan';

    protected $fillable = [
        'tes_kesehatan_anamnesa_id',
        'nama_pemeriksa',
        'tanggal_pemeriksaan',
        'tinggi_badan',
        'berat_badan',
        'tekanan_darah',
        'konjungtiva',
        'ikhterik',
        'buta_warna',
        'respon_pendengaran',
        'kelengkapan_jari_atas',
        'tremor',
        'kidal',
        'bekas_luka_sayatan',
        'bunyi_jantung',
        'bunyi_paru',
        'catatan',
        'rekomendasi',
    ];

    /* ==============================
     * 🔗 RELATIONSHIPS
     * ============================== */
    protected $casts = [
        'tanggal_pengisian' => 'datetime',
    ];

    public function anamnesa()
    {
        return $this->belongsTo(TesKesehatanAnamnesa::class, 'tes_kesehatan_anamnesa_id');
    }

    public function user()
    {
        return $this->hasOneThrough(
            User::class,
            TesKesehatanAnamnesa::class,
            'id',
            'id',
            'tes_kesehatan_anamnesa_id',
            'user_id'
        );
    }
}
