<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TesKesehatanAnamnesa extends Model
{
    use HasFactory;

    protected $table = 'tes_kesehatan_anamnesa';

    protected $fillable = [
        'user_id',
        'admin_id',
        'tanggal_pengisian',

        // 1 - 5
        'riwayat_penyakit_keluarga',
        'riwayat_penyakit_pribadi',
        'riwayat_operasi',
        'konsumsi_obat_rutin',
        'penyakit_menular',

        // 6 - 10
        'masalah_kulit',
        'tumor_benjolan',          // ⬅️ tambahan
        'epilepsi',
        'cedera_kepala',
        'batuk_kronis',

        // 11 - 15
        'gangguan_pencernaan',
        'gangguan_keseimbangan',
        'claustrophobia',
        'takut_darah',
        'kacamata',

        // 16 - 21
        'gagap',                   // ⬅️ tambahan
        'alat_bantu_tulang',
        'lemah_otot',
        'pikiran_bunuh_diri',
        'kelainan_darah',          // ⬅️ tambahan
        'riwayat_psikolog',

        // tambahan umum
        'keterangan',
        'status',
    ];


    /* ==============================
     * 🔗 RELATIONSHIPS
     * ============================== */

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function admin()
    {
        return $this->belongsTo(Admin::class, 'admin_id');
    }

    public function pemeriksaan()
    {
        return $this->hasOne(TesKesehatanPemeriksaan::class);
    }
}
