<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Jurusan extends Model
{
    use HasFactory, SoftDeletes;

    // Nama tabel, jika berbeda dengan nama default (yakni nama model jamak)
    protected $table = 'jurusan';

    // Field yang dapat diisi
    protected $fillable = [
        'kd_jurusan',
        'nama_jurusan',
        'deskripsi',
    ];
    public function mahasiswaBaru()
    {
        return $this->hasMany(User::class, 'jurusan_id');
    }
    public function wawancaraPmb()
    {
        return $this->hasMany(WawancaraPmb::class, 'jurusan_id');
    }
}
